set search_path = stop_frisk, public;
-- Create main stops table and hypertable
  
DROP TABLE IF EXISTS "stops" CASCADE;
CREATE TABLE "stops"(
    gid serial,
    datetime TIMESTAMP,
    weekday varchar,
    "location" varchar,
    district varchar,
    psa varchar,
    stop_code int,
    stop_type int,
    inside_outside int,
    gender varchar,
    race int,
    "age" int,
    individual_frisked int,
    individual_searched int,
    individual_arrested int,
    individual_contraband int,
    vehicle_frisked int,
    vehicle_searched int,
    vehicle_contraband int,
    lat double precision,
    lon double PRECISION
   );
SELECT create_hypertable('stops', 'datetime', 'race', 2, create_default_indexes=>FALSE);
create index on stops (race, datetime desc);
create index on stops (district, datetime desc);

-- Create a gender lookup table.

DROP TABLE IF EXISTS gender CASCADE;
CREATE TABLE IF NOT EXISTS "gender"(
    gender INTEGER,
    description TEXT
);
INSERT INTO gender(gender, description) VALUES
(0, 'Male'),
(1, 'Female');

-- Create a race lookup table

DROP TABLE IF EXISTS race CASCADE;
CREATE TABLE IF NOT EXISTS "race"(
    race INTEGER,
    description TEXT
);
INSERT INTO race(race, description) VALUES
(0, 'Unknown'),
(1, 'Asian'),
(2, 'Black - Non-Latino'),
(3, 'Black - Latino'),
(4, 'White - Non-Latino'),
(5, 'White - Latino'),
(6, 'American Indian');

-- Create a stop_type lookup table

DROP TABLE IF EXISTS stop_type CASCADE;
CREATE TABLE IF NOT EXISTS "stop_type"(
    stop_type INTEGER,
    description TEXT
);
INSERT INTO stop_type(stop_type, description) VALUES
(0, 'Vehicle'),
(1, 'Pedestrian');

-- Create a area_type lookup table

DROP TABLE IF EXISTS inside_outside CASCADE;
CREATE TABLE IF NOT EXISTS inside_outside(
    inside_outside INTEGER,
    description TEXT
);
INSERT INTO inside_outside(inside_outside, description) VALUES
(0, 'Outside'),
(1, 'Inside');





